# Nova OS Android — Preview 0.4

Aplikasi Android dengan desktop bergaya Windows.

## Fitur
- Daftar aplikasi Android yang menyediakan launcher, lengkap dengan ikon asli dan nama aplikasi.
- Beberapa aplikasi yang terpasang ditampilkan sebagai ikon desktop; daftar lengkap tersedia di menu Mulai.
- Menekan ikon akan membuka aplikasi Android asli melalui intent peluncur Android.
- Browser internet memakai Android WebView.
- File Manager memakai Android Storage Access Framework untuk menjelajahi lokasi yang dipilih pengguna, membuka dan membagikan file, serta membuat folder jika diizinkan.
- Pengaturan membuka halaman Pengaturan Android yang asli.

## Batasan dan privasi
- Nova OS tidak mengkloning aplikasi dan tidak menjalankan aplikasi Android di dalam jendela desktop; aplikasi dibuka sebagai aplikasi Android biasa.
- Daftar yang terlihat adalah aplikasi yang memiliki aktivitas peluncur. Beberapa aplikasi sistem tersembunyi tidak muncul.
- Ikon dan nama aplikasi dibaca dari PackageManager Android. Manifest menggunakan deklarasi `<queries>` untuk mencari aktivitas launcher; tidak meminta izin akses seluruh file.
- File Manager hanya melihat lokasi yang secara eksplisit dipilih pengguna.

## Build APK tanpa komputer
Unggah folder proyek ini ke GitHub (atau gunakan paket Cloud Build Kit), lalu jalankan workflow GitHub Actions. Build memakai JDK 17, Gradle 8.9, dan Android Gradle Plugin 8.7.3.
