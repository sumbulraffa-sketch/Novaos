package com.novaos.desktop;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(21,35,57));getWindow().setNavigationBarColor(Color.rgb(21,35,57));
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,16,16,16);root.setBackgroundColor(Color.rgb(244,247,252));
  TextView title=new TextView(this);title.setText("⚙  Pengaturan Nova");title.setTextSize(25);title.setTextColor(Color.rgb(27,43,65));root.addView(title);
  TextView sub=new TextView(this);sub.setText("Pintasan ke pengaturan asli Android di tablet ini.");sub.setTextColor(Color.DKGRAY);sub.setPadding(0,6,0,14);root.addView(sub);
  add(root,"📶  Wi-Fi & jaringan","Mengatur jaringan pada Android",Settings.ACTION_WIFI_SETTINGS);
  add(root,"🖥️  Layar","Kecerahan, ukuran tampilan, dan layar",Settings.ACTION_DISPLAY_SETTINGS);
  add(root,"🔊  Suara","Volume dan suara perangkat",Settings.ACTION_SOUND_SETTINGS);
  add(root,"🔋  Baterai","Informasi dan penggunaan baterai",Intent.ACTION_POWER_USAGE_SUMMARY);
  add(root,"📱  Aplikasi","Mengelola aplikasi yang terpasang",Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS);
  add(root,"🔐  Izin aplikasi Nova","Izin dan detail aplikasi Nova OS", "APP_DETAILS");
  add(root,"⚙️  Semua pengaturan Android","Membuka halaman utama Pengaturan Android",Settings.ACTION_SETTINGS);
  TextView note=new TextView(this);note.setText("Catatan: halaman yang terbuka adalah pengaturan asli Android, bukan pengaturan Windows. Android tetap mengontrol keamanan dan izin perangkat.");note.setTextColor(Color.GRAY);note.setTextSize(12);note.setPadding(2,16,2,8);root.addView(note);setContentView(root);
 }
 private void add(LinearLayout root,String title,String detail,String action){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(13,10,13,10);card.setBackgroundColor(Color.WHITE);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);root.addView(card,lp);TextView t=new TextView(this);t.setText(title);t.setTextSize(16);t.setTextColor(Color.rgb(32,48,70));card.addView(t);TextView d=new TextView(this);d.setText(detail);d.setTextSize(12);d.setTextColor(Color.GRAY);card.addView(d);card.setOnClickListener(v->{try{Intent i;if(action.equals("APP_DETAILS"))i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:"+getPackageName()));else i=new Intent(action);startActivity(i);}catch(Exception e){Toast.makeText(this,"Pengaturan ini tidak tersedia di perangkat",Toast.LENGTH_SHORT).show();}});}
}
