package com.novaos.desktop;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.net.Uri;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.view.View;

public class BrowserActivity extends Activity {
    private WebView browser; private EditText address; private ProgressBar progress; private TextView status;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(21,35,57)); getWindow().setNavigationBarColor(Color.rgb(21,35,57));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(245,248,252));
        LinearLayout bar = new LinearLayout(this); bar.setPadding(6,6,6,6); bar.setGravity(android.view.Gravity.CENTER_VERTICAL); bar.setOrientation(LinearLayout.HORIZONTAL); bar.setBackgroundColor(Color.rgb(230,237,247));
        Button back = button("‹"); bar.addView(back, new LinearLayout.LayoutParams(42,48));
        Button forward = button("›"); bar.addView(forward, new LinearLayout.LayoutParams(42,48));
        Button reload = button("↻"); bar.addView(reload, new LinearLayout.LayoutParams(42,48));
        address = new EditText(this); address.setSingleLine(true); address.setTextSize(14); address.setPadding(12,0,12,0); address.setHint("Cari atau masukkan alamat situs"); address.setImeOptions(EditorInfo.IME_ACTION_GO); address.setSelectAllOnFocus(true); bar.addView(address, new LinearLayout.LayoutParams(0,48,1));
        Button go = button("Buka"); bar.addView(go, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,48));
        root.addView(bar, new LinearLayout.LayoutParams(-1,-2));
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setMax(100); root.addView(progress,new LinearLayout.LayoutParams(-1,3));
        browser = new WebView(this); WebSettings s=browser.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setLoadsImagesAutomatically(true); s.setJavaScriptCanOpenWindowsAutomatically(true); s.setSupportMultipleWindows(false); s.setMediaPlaybackRequiresUserGesture(true); browser.setWebChromeClient(new WebChromeClient(){@Override public void onProgressChanged(WebView view,int p){progress.setProgress(p);progress.setVisibility(p>=100?View.GONE:View.VISIBLE);}}); browser.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView view,String url){address.setText(url);status.setText("Selesai memuat");}}); root.addView(browser,new LinearLayout.LayoutParams(-1,0,1));
        status = new TextView(this); status.setText("Siap"); status.setTextSize(11); status.setPadding(10,3,10,3); status.setTextColor(Color.DKGRAY); root.addView(status,new LinearLayout.LayoutParams(-1,-2)); setContentView(root);
        String initial=getIntent().getStringExtra("url"); if(initial==null)initial="https://www.google.com"; load(initial);
        go.setOnClickListener(v -> load(address.getText().toString()));
        address.setOnEditorActionListener((v, action, event) -> {if(action==EditorInfo.IME_ACTION_GO || action==EditorInfo.IME_NULL){load(address.getText().toString());return true;}return false;});
        back.setOnClickListener(v->{if(browser.canGoBack())browser.goBack();}); forward.setOnClickListener(v->{if(browser.canGoForward())browser.goForward();}); reload.setOnClickListener(v->browser.reload());
        browser.setDownloadListener((url, ua, cd, mime, len) -> {try{startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){status.setText("Tidak ada aplikasi untuk mengunduh tautan ini");}});
    }
    private Button button(String t){Button b=new Button(this);b.setText(t);b.setAllCaps(false);b.setTextSize(17);return b;}
    private void load(String raw){String u=raw==null?"":raw.trim();if(u.isEmpty())return;if(!u.matches("(?i)^https?://.*")){if(u.contains(" ")||!u.contains("."))u="https://www.google.com/search?q="+Uri.encode(u);else u="https://"+u;}address.setText(u);status.setText("Memuat...");progress.setVisibility(View.VISIBLE);browser.loadUrl(u);}
    @Override public void onBackPressed(){if(browser!=null&&browser.canGoBack())browser.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(browser!=null)browser.destroy();super.onDestroy();}
}
