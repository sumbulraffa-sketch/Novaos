package com.novaos.desktop;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.database.Cursor;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class FileManagerActivity extends Activity {
    private static final int PICK_TREE=40;
    private Uri treeUri, currentUri;
    private LinearLayout list;
    private TextView pathLabel, emptyLabel;
    private final ArrayList<Uri> parents = new ArrayList<>();
    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.rgb(21,35,57));getWindow().setNavigationBarColor(Color.rgb(21,35,57));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(246,249,253));
        TextView title=new TextView(this);title.setText("📁  Nova File Manager");title.setTextSize(21);title.setTextColor(Color.rgb(28,45,68));title.setPadding(16,16,12,12);root.addView(title);
        LinearLayout tools=new LinearLayout(this);tools.setPadding(8,4,8,8);
        Button choose=button("Pilih lokasi");tools.addView(choose,new LinearLayout.LayoutParams(0,46,1));Button up=button("Naik ↑");tools.addView(up,new LinearLayout.LayoutParams(0,46,1));Button folder=button("+ Folder");tools.addView(folder,new LinearLayout.LayoutParams(0,46,1));root.addView(tools);
        pathLabel=new TextView(this);pathLabel.setText("Pilih lokasi penyimpanan untuk mulai");pathLabel.setTextColor(Color.DKGRAY);pathLabel.setPadding(14,8,14,8);root.addView(pathLabel);
        ScrollView scroll=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView note=new TextView(this);note.setText("Akses file mengikuti izin Android. Folder sistem tertentu mungkin tidak bisa dibuka.");note.setTextSize(11);note.setTextColor(Color.GRAY);note.setPadding(12,8,12,10);root.addView(note);setContentView(root);
        choose.setOnClickListener(v->pickTree());up.setOnClickListener(v->goUp());folder.setOnClickListener(v->createFolder());
        if(state!=null&&state.getString("tree")!=null){treeUri=Uri.parse(state.getString("tree"));currentUri=state.getString("current")!=null?Uri.parse(state.getString("current")):DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri));refresh();}else pickTree();
    }
    private Button button(String t){Button b=new Button(this);b.setText(t);b.setAllCaps(false);return b;}
    private void pickTree(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_TREE);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==PICK_TREE&&result==RESULT_OK&&data!=null){treeUri=data.getData();int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);try{getContentResolver().takePersistableUriPermission(treeUri,flags);}catch(Exception ignored){}currentUri=DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri));parents.clear();refresh();}}
    private String docId(Uri uri){return DocumentsContract.getDocumentId(uri);}
    private Uri childrenUri(Uri parent){return DocumentsContract.buildChildDocumentsUriUsingTree(treeUri,docId(parent));}
    private void refresh(){list.removeAllViews();if(treeUri==null){pathLabel.setText("Belum ada lokasi dipilih");return;}String id="Penyimpanan yang dipilih";try{id=docId(currentUri);}catch(Exception ignored){}pathLabel.setText("Lokasi: "+id.replace(':','/'));int count=0;
        String[] cols={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_SIZE,DocumentsContract.Document.COLUMN_LAST_MODIFIED};
        try(Cursor c=getContentResolver().query(childrenUri(currentUri),cols,null,null,DocumentsContract.Document.COLUMN_DISPLAY_NAME+" ASC")){
            if(c!=null)while(c.moveToNext()){String childId=c.getString(0),name=c.getString(1),mime=c.getString(2);long size=c.isNull(3)?-1:c.getLong(3);long modified=c.isNull(4)?0:c.getLong(4);Uri child=DocumentsContract.buildDocumentUriUsingTree(treeUri,childId);addItem(child,name,mime,size,modified);count++;}
        }catch(Exception e){Toast.makeText(this,"Folder ini tidak dapat dibaca: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        if(count==0){TextView empty=new TextView(this);empty.setText("Folder kosong atau Android tidak mengizinkan akses ke isinya.");empty.setPadding(18,24,18,24);empty.setTextColor(Color.GRAY);list.addView(empty);}
    }
    private void addItem(Uri uri,String name,String mime,long size,long modified){boolean dir=DocumentsContract.Document.MIME_TYPE_DIR.equals(mime);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(android.view.Gravity.CENTER_VERTICAL);row.setPadding(12,9,8,9);row.setBackgroundColor(Color.WHITE);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(8,3,8,3);list.addView(row,rp);
        TextView icon=new TextView(this);icon.setText(dir?"📁":"📄");icon.setTextSize(24);row.addView(icon,new LinearLayout.LayoutParams(44,48));LinearLayout textCol=new LinearLayout(this);textCol.setOrientation(LinearLayout.VERTICAL);TextView label=new TextView(this);label.setText(name==null?"Tanpa nama":name);label.setTextSize(15);label.setTextColor(Color.rgb(32,48,69));TextView detail=new TextView(this);detail.setText(dir?"Folder":(size>=0?formatSize(size):mime));detail.setTextSize(11);detail.setTextColor(Color.GRAY);textCol.addView(label);textCol.addView(detail);row.addView(textCol,new LinearLayout.LayoutParams(0,-2,1));row.setOnClickListener(v->{if(dir){parents.add(currentUri);currentUri=uri;refresh();}else openDocument(uri,mime);});row.setOnLongClickListener(v->{new android.app.AlertDialog.Builder(this).setTitle(name).setItems(new String[]{"Buka","Bagikan file"},(d,which)->{if(which==0)openDocument(uri,mime);else shareDocument(uri,mime);}).show();return true;});}
    private String formatSize(long s){if(s<1024)return s+" B";if(s<1024*1024)return String.format(java.util.Locale.US,"%.1f KB",s/1024.0);return String.format(java.util.Locale.US,"%.1f MB",s/(1024.0*1024));}
    private void openDocument(Uri uri,String mime){try{Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uri,mime==null||mime.equals("application/octet-stream")?"*/*":mime);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Buka file dengan"));}catch(Exception e){Toast.makeText(this,"Tidak ada aplikasi yang dapat membuka file ini",Toast.LENGTH_LONG).show();}}
    private void shareDocument(Uri uri,String mime){Intent i=new Intent(Intent.ACTION_SEND);i.setType(mime==null?"*/*":mime);i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Bagikan file"));}
    private void goUp(){if(treeUri==null)return;if(!parents.isEmpty()){currentUri=parents.remove(parents.size()-1);refresh();}else if(!currentUri.equals(treeUri)){currentUri=treeUri;refresh();}else Toast.makeText(this,"Sudah di folder awal",Toast.LENGTH_SHORT).show();}
    private void createFolder(){if(treeUri==null){pickTree();return;}EditText input=new EditText(this);input.setHint("Nama folder baru");new android.app.AlertDialog.Builder(this).setTitle("Buat folder").setView(input).setNegativeButton("Batal",null).setPositiveButton("Buat",(d,w)->{String name=input.getText().toString().trim();if(name.isEmpty())return;try{DocumentsContract.createDocument(getContentResolver(),currentUri,DocumentsContract.Document.MIME_TYPE_DIR,name);refresh();Toast.makeText(this,"Folder dibuat",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Gagal membuat folder. Pastikan izin tulis tersedia.",Toast.LENGTH_LONG).show();}}).show();}
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);if(treeUri!=null)out.putString("tree",treeUri.toString());if(currentUri!=null)out.putString("current",currentUri.toString());}
}
