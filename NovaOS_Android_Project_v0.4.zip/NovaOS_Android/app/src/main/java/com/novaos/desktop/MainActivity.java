package com.novaos.desktop;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new NovaBridge(), "NovaAndroid");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public class NovaBridge {
        @JavascriptInterface public void openBrowser(String raw) {
            runOnUiThread(() -> {
                String url = normalize(raw);
                Intent i = new Intent(MainActivity.this, BrowserActivity.class);
                i.putExtra("url", url);
                startActivity(i);
            });
        }
        @JavascriptInterface public void openFiles() {
            runOnUiThread(() -> startActivity(new Intent(MainActivity.this, FileManagerActivity.class)));
        }
        @JavascriptInterface public void openSettings() {
            runOnUiThread(() -> startActivity(new Intent(MainActivity.this, SettingsActivity.class)));
        }
        @JavascriptInterface public void notifyUser(String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }
        @JavascriptInterface public String getInstalledApps() {
            JSONArray result = new JSONArray();
            try {
                Intent query = new Intent(Intent.ACTION_MAIN, null);
                query.addCategory(Intent.CATEGORY_LAUNCHER);
                PackageManager pm = getPackageManager();
                List<ResolveInfo> activities = pm.queryIntentActivities(query, 0);
                Collections.sort(activities, new Comparator<ResolveInfo>() {
                    @Override public int compare(ResolveInfo a, ResolveInfo b) {
                        return String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm)));
                    }
                });
                String own = getPackageName();
                for (ResolveInfo ri : activities) {
                    ActivityInfo ai = ri.activityInfo;
                    if (ai == null || own.equals(ai.packageName)) continue;
                    JSONObject app = new JSONObject();
                    app.put("label", String.valueOf(ri.loadLabel(pm)));
                    app.put("packageName", ai.packageName);
                    app.put("icon", iconAsDataUri(ri.loadIcon(pm)));
                    result.put(app);
                }
            } catch (Exception ignored) { }
            return result.toString();
        }
        @JavascriptInterface public void launchApp(String packageName) {
            runOnUiThread(() -> {
                try {
                    if (packageName == null || packageName.trim().isEmpty()) return;
                    Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
                    if (launch == null) {
                        Toast.makeText(MainActivity.this, "Aplikasi tidak menyediakan pintasan untuk dibuka", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka aplikasi ini", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private String iconAsDataUri(Drawable drawable) {
        try {
            int size = 72;
            Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, size, size);
            drawable.draw(canvas);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 90, out);
            bitmap.recycle();
            return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) { return ""; }
    }

    private String normalize(String raw) {
        String url = raw == null ? "" : raw.trim();
        if (url.isEmpty()) return "https://www.google.com";
        if (!url.matches("(?i)^https?://.*")) {
            if (url.contains(" ") || !url.contains(".")) return "https://www.google.com/search?q=" + Uri.encode(url);
            return "https://" + url;
        }
        return url;
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
