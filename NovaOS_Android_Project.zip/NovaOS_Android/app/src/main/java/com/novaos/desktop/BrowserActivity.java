package com.novaos.desktop;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.ViewGroup;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.net.Uri;

public class BrowserActivity extends Activity {
    private WebView browser; private EditText address;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(245,248,252));
        LinearLayout bar = new LinearLayout(this); bar.setPadding(8,8,8,8); bar.setOrientation(LinearLayout.HORIZONTAL); bar.setBackgroundColor(Color.rgb(230,237,247));
        Button back = new Button(this); back.setText("‹"); bar.addView(back, new LinearLayout.LayoutParams(48, 48));
        address = new EditText(this); address.setSingleLine(true); address.setHint("Cari atau masukkan alamat situs"); address.setTextSize(14); address.setImeOptions(EditorInfo.IME_ACTION_GO); bar.addView(address, new LinearLayout.LayoutParams(0,48,1));
        Button go = new Button(this); go.setText("Buka"); bar.addView(go, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,48));
        root.addView(bar, new LinearLayout.LayoutParams(-1,-2));
        browser = new WebView(this); WebSettings s=browser.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setLoadsImagesAutomatically(true); browser.setWebChromeClient(new WebChromeClient()); browser.setWebViewClient(new WebViewClient()); root.addView(browser,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        String initial=getIntent().getStringExtra("url"); if(initial==null) initial="https://www.google.com"; load(initial);
        go.setOnClickListener(v -> load(address.getText().toString()));
        address.setOnEditorActionListener((v, action, event) -> { if(action==EditorInfo.IME_ACTION_GO){load(address.getText().toString());return true;}return false; });
        back.setOnClickListener(v -> {if(browser.canGoBack())browser.goBack();else finish();});
        browser.setDownloadListener((url, ua, cd, mime, len) -> { android.content.Intent i=new android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(url)); try{startActivity(i);}catch(Exception ignored){} });
    }
    private void load(String raw){String u=raw==null?"":raw.trim();if(u.isEmpty())return;if(!u.matches("(?i)^https?://.*")){if(u.contains(" ")||!u.contains("."))u="https://www.google.com/search?q="+Uri.encode(u);else u="https://"+u;}address.setText(u);browser.loadUrl(u);}
    @Override public void onBackPressed(){if(browser.canGoBack())browser.goBack();else super.onBackPressed();}
}
