package com.novaos.desktop;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new NovaBridge(), "NovaAndroid");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    public class NovaBridge {
        @JavascriptInterface public void openBrowser(String raw) {
            runOnUiThread(() -> {
                String url = raw == null ? "" : raw.trim();
                if (url.isEmpty()) url = "https://www.google.com";
                if (!url.matches("(?i)^https?://.*")) {
                    if (url.contains(" ") || !url.contains(".")) url = "https://www.google.com/search?q=" + Uri.encode(url);
                    else url = "https://" + url;
                }
                Intent i = new Intent(MainActivity.this, BrowserActivity.class);
                i.putExtra("url", url);
                startActivity(i);
            });
        }
        @JavascriptInterface public void openFiles() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivity(Intent.createChooser(i, "Pilih file untuk dibuka"));
            });
        }
        @JavascriptInterface public void chooseFolder() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                startActivity(Intent.createChooser(i, "Pilih folder"));
            });
        }
        @JavascriptInterface public void notifyUser(String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
