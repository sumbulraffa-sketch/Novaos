# Nova OS Android (proyek sumber)

Proyek ini membungkus desktop simulasi Nova OS dalam aplikasi Android berbasis WebView.

## Fitur
- Desktop, menu Mulai, taskbar, jendela aplikasi.
- Browser internet terpisah di dalam aplikasi (WebView) dengan address bar, tombol kembali, dan pencarian.
- File Manager sederhana yang memakai pemilih file/folder resmi Android (Storage Access Framework).
- Notepad dan kalkulator simulasi.

## Membuat APK
APK belum disertakan karena lingkungan pembuatan ini tidak memiliki Android SDK/Gradle untuk mengompilasi aplikasi.
1. Pindahkan folder proyek ini ke komputer yang memiliki Android Studio.
2. Buka folder `NovaOS_Android` di Android Studio.
3. Izinkan Gradle melakukan sinkronisasi dan pasang Android SDK Platform 35 jika diminta.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya dibuat di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Ini adalah aplikasi Android dengan tampilan desktop, bukan OS yang menggantikan Android.
- Browser membutuhkan koneksi internet.
- File Manager menggunakan pemilih file/folder Android. Android meminta pengguna memilih file/folder yang boleh diakses; aplikasi tidak diberi akses bebas ke seluruh file.
- Jangan gunakan untuk menyimpan data penting; ini masih versi percobaan.
